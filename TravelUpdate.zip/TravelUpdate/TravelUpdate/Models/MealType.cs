﻿namespace TravelUpdate.Models
{
    public class MealType
    {
        public int MealTypeID { get; set; }
        public string TypeName { get; set; } = "";
        
    }
}
