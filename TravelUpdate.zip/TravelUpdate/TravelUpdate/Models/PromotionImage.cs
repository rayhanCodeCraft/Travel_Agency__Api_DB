﻿namespace TravelUpdate.Models
{
    public class PromotionImage
    {
        public int PromotionImageId { get; set; }
        public string PromotionImageUrl { get; set; }
    }
}
