﻿using System.ComponentModel.DataAnnotations;

namespace TravelUpdate.Models
{
    public class Transportation /*: BaseClass*/
    {
        public int TransportationId { get; set; }



        public bool IsActive { get; set; }
        public int TransportProviderId { get; set; }

        [StringLength(500)]
        public string Description { get; set; }
        //[Range(1, 5)]
        //public int Rating { get; set; }



     
        public TransportProvider TransportProvider { get; set; }



        public ICollection<PackageTransportation> PackageTransportations { get; set; }
    }

}
