﻿namespace TravelUpdate.Models
{
    public class TransportationCatagory
    {
        public int TransportationCatagoryId { get; set; }
        public string TransportationCatagoryName { get; set; }
    }
}