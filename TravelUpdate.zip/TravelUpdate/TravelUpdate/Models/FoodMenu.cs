﻿//namespace TravelUpdate.Models
//{
//    public class FoodMenu
//    {
//        public int FoodMenuID { get; set; }
//        public int FoodItemID {  get; set; }
//        public virtual FoodItem? FoodItem { get; set; }


//    }
//}
