﻿namespace TravelUpdate.Models
{
    public class BasicDateTime:FunctionalDate
    {
        public DateTime TentativeDate { get; set; }
        public DateTime ActualDate { get; set; }
    }
}
