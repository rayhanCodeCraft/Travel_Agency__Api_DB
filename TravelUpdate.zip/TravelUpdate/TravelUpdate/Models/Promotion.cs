﻿using System.ComponentModel.DataAnnotations.Schema;

namespace TravelUpdate.Models
{
    public class Promotion
    {
        public int PromotionId { get; set; }
        public string PromotionTitle { get; set; }
        public string PromoCode { get; set; }
        public string PromotionType { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        public decimal DiscountPercentage { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Description { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime UpdatedAt { get; set; } = DateTime.Now;

        // Foreign Key
        public int PromotionImageId { get; set; }
        public PromotionImage PromotionImage { get; set; }
    }
}
