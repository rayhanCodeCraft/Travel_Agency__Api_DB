﻿namespace TravelUpdate.Models
{
    public class PaymentStatus
    {
        public int PaymentStatusId { get; set; }
        public string PaymentStatusType { get; set; }
    }
}
