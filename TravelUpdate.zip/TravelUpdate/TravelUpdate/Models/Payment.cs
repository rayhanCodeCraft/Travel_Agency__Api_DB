﻿using System.ComponentModel.DataAnnotations.Schema;

namespace TravelUpdate.Models
{

    public class Payment
    {
        public int PaymentId { get; set; }
        public int BookingId { get; set; }

        // Make PromotionId nullable
        public int? PromotionId { get; set; }

        public int PaymentStatusId { get; set; }
        public int PaymentMethodId { get; set; }
        public string? SubmittedPromo { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        public decimal FinalAmount { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        public decimal AmountPaid { get; set; }
        public string Currency { get; set; }
        public DateTime PaymentDate { get; set; } = DateTime.Now;
        public string? StripePaymentIntentId { get; set; }
        public string TransactionId { get; set; }
        public string MobileNumber { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }

        // Navigation properties
        public PaymentMethod PaymentMethod { get; set; }
        public PaymentStatus PaymentStatus { get; set; }
        public Booking Booking { get; set; }
        public Promotion? Promotion { get; set; } 
    }

    
}
