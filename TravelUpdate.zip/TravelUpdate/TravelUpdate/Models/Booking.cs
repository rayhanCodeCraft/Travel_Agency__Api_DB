﻿namespace TravelUpdate.Models
{
    public class Booking
    {
        public int BookingId { get; set; }
        public string ApplicationUserId { get; set; } = "";
        public int PackageID { get; set; }
        public DateTime BookingDate { get; set; } = DateTime.Now;
        public int NumberOfTravelers { get; set; }
        public bool IsCoupleBooking { get; set; }
       
        public string Status { get; set; }

        public ApplicationUser ApplicationUser { get; set; }
        public Package Package { get; set; }
    }
}
