﻿namespace TravelUpdate.Models
{
    public class PackageUser : FunctionalDate
    {
        public int ID { get; set; }

        public int PackageID { get; set; }
        public Package? Package { get; set; }

        public string PackageResponsibility { get; set; }
        public string ApplicationUserId { get; set; }
        public ApplicationUser ApplicationUser { get; set; }
    }

}
