﻿using System.ComponentModel.DataAnnotations.Schema;

namespace TravelUpdate.Models
{
    public class Hotel
    {
        public int HotelId { get; set; }
        public string HotelName { get; set; }
        public string Description { get; set; }
        public int StarRating { get; set; }
        public string Address { get; set; } // Address can be broken down further if needed
        public string ContactInfo { get; set; } // If contact is multi-value, consider splitting
        public string HotelCode { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal AverageRoomRate { get; set; }

        // Foreign Key
        public int LocationID { get; set; }
        public Location Location { get; set; }

        // Relationships
        public ICollection<HotelImage> HotelImages { get; set; }
        public ICollection<Room> Rooms { get; set; }
        public ICollection<PackageAccommodation> PackageAccommodations { get; set; }
        public ICollection<HotelFacility> HotelFacilities { get; set; } // Hotel <-> Facility many-to-many
    }

}
