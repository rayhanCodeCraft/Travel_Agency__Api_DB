﻿namespace TravelUpdate.Models
{
    public class Seats
    {
        public int SeatsId { get; set; }
        public string SeatsNumber { get; set; }
    }
}