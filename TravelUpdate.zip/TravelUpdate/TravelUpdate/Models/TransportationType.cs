﻿using System.ComponentModel.DataAnnotations;

namespace TravelUpdate.Models
{
    public class TransportationType
    {
        public int TransportationTypeId { get; set; }

        [Required]
        [StringLength(50)]
        public string TypeName { get; set; } // AC, Non ac, double dacker, air, train etc

        public ICollection<Transportation> Transportations { get; set; }
    }
}