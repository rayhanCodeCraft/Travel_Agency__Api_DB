﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace TravelUpdate.Models
{
    public class FoodItem /*: BaseClass*/
    {
        [Key]
        public int FoodItemID { get; set; } = 1;   
        [Required]
        public string ItemName { get; set; } = "Parota";       
        [Required]
        public DateTime CreatedAt { get; set; }=DateTime.Now;
        [Required]
        public DateTime UpdatedAt { get; set; }= DateTime.Now;

        public ICollection<PackageFoodItem> PackageMenus { get; set; }= new List<PackageFoodItem>();
    }

}



//[Required]
//public int MealTitleID { get; set; }  // Foreign key pointing to MealTitle
//[Required]
//[Column(TypeName = "decimal(18,2)")] // cost per person
//public decimal PerPersonPrice { get; set; }
// Navigation properties
//[ForeignKey("MealTitleID")]  // Correct foreign key reference
//public MealTitle MealTitle { get; set; }  