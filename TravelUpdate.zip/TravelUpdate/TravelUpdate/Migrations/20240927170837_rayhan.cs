﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TravelUpdate.Migrations
{
    /// <inheritdoc />
    public partial class rayhan : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Transportation_TransportationTypes_TransportationTypeId",
                table: "Transportation");

            migrationBuilder.DropColumn(
                name: "Rating",
                table: "Transportation");

            migrationBuilder.AlterColumn<int>(
                name: "TransportationTypeId",
                table: "Transportation",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<string>(
                name: "PackageTransportationDescription",
                table: "PackageTransportations",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "SeatBooked",
                table: "PackageTransportations",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "TransportationCatagoryId",
                table: "PackageTransportations",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "TransportationTypeId",
                table: "PackageTransportations",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "Seats",
                columns: table => new
                {
                    SeatsId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SeatsNumber = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    PackageTransportationID = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Seats", x => x.SeatsId);
                    table.ForeignKey(
                        name: "FK_Seats_PackageTransportations_PackageTransportationID",
                        column: x => x.PackageTransportationID,
                        principalTable: "PackageTransportations",
                        principalColumn: "ID");
                });

            migrationBuilder.CreateTable(
                name: "TransportationCatagories",
                columns: table => new
                {
                    TransportationCatagoryId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TransportationCatagoryName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TransportationCatagories", x => x.TransportationCatagoryId);
                });

            migrationBuilder.CreateIndex(
                name: "IX_PackageTransportations_TransportationCatagoryId",
                table: "PackageTransportations",
                column: "TransportationCatagoryId");

            migrationBuilder.CreateIndex(
                name: "IX_PackageTransportations_TransportationTypeId",
                table: "PackageTransportations",
                column: "TransportationTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Seats_PackageTransportationID",
                table: "Seats",
                column: "PackageTransportationID");

            migrationBuilder.AddForeignKey(
                name: "FK_PackageTransportations_TransportationCatagories_TransportationCatagoryId",
                table: "PackageTransportations",
                column: "TransportationCatagoryId",
                principalTable: "TransportationCatagories",
                principalColumn: "TransportationCatagoryId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_PackageTransportations_TransportationTypes_TransportationTypeId",
                table: "PackageTransportations",
                column: "TransportationTypeId",
                principalTable: "TransportationTypes",
                principalColumn: "TransportationTypeId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Transportation_TransportationTypes_TransportationTypeId",
                table: "Transportation",
                column: "TransportationTypeId",
                principalTable: "TransportationTypes",
                principalColumn: "TransportationTypeId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PackageTransportations_TransportationCatagories_TransportationCatagoryId",
                table: "PackageTransportations");

            migrationBuilder.DropForeignKey(
                name: "FK_PackageTransportations_TransportationTypes_TransportationTypeId",
                table: "PackageTransportations");

            migrationBuilder.DropForeignKey(
                name: "FK_Transportation_TransportationTypes_TransportationTypeId",
                table: "Transportation");

            migrationBuilder.DropTable(
                name: "Seats");

            migrationBuilder.DropTable(
                name: "TransportationCatagories");

            migrationBuilder.DropIndex(
                name: "IX_PackageTransportations_TransportationCatagoryId",
                table: "PackageTransportations");

            migrationBuilder.DropIndex(
                name: "IX_PackageTransportations_TransportationTypeId",
                table: "PackageTransportations");

            migrationBuilder.DropColumn(
                name: "PackageTransportationDescription",
                table: "PackageTransportations");

            migrationBuilder.DropColumn(
                name: "SeatBooked",
                table: "PackageTransportations");

            migrationBuilder.DropColumn(
                name: "TransportationCatagoryId",
                table: "PackageTransportations");

            migrationBuilder.DropColumn(
                name: "TransportationTypeId",
                table: "PackageTransportations");

            migrationBuilder.AlterColumn<int>(
                name: "TransportationTypeId",
                table: "Transportation",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Rating",
                table: "Transportation",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddForeignKey(
                name: "FK_Transportation_TransportationTypes_TransportationTypeId",
                table: "Transportation",
                column: "TransportationTypeId",
                principalTable: "TransportationTypes",
                principalColumn: "TransportationTypeId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
